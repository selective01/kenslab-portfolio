import { NextResponse } from "next/server";
import nodemailer from "nodemailer";

export async function POST(request: Request) {
  try {
    const { email, name, type, comment } = await request.json();

    if (!email || !name || !comment) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Check env vars are set
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
      console.error("❌ EMAIL_USER or EMAIL_PASS not set in .env.local");
      return NextResponse.json(
        { error: "Email not configured. Please set EMAIL_USER and EMAIL_PASS in .env.local" },
        { status: 500 }
      );
    }

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    // Verify connection before sending
    await transporter.verify();

    await transporter.sendMail({
      from:    `"Ken'sLab Portfolio" <${process.env.EMAIL_USER}>`,
      to:      process.env.EMAIL_TO || "kceeemmanuel01@gmail.com",
      replyTo: email,
      subject: `New Contact — ${name} (${type || "No type"})`,
      html: `
        <div style="font-family: sans-serif; max-width: 600px; padding: 20px;">
          <h2 style="color: #e8671a; margin-bottom: 16px;">New Message from Ken'sLab Portfolio</h2>
          <table style="width:100%; border-collapse: collapse; font-size: 14px;">
            <tr style="border-bottom: 1px solid #eee;">
              <td style="padding: 10px 8px; color: #888; width: 90px; font-weight: bold;">Name</td>
              <td style="padding: 10px 8px;">${name}</td>
            </tr>
            <tr style="border-bottom: 1px solid #eee;">
              <td style="padding: 10px 8px; color: #888; font-weight: bold;">Email</td>
              <td style="padding: 10px 8px;"><a href="mailto:${email}">${email}</a></td>
            </tr>
            <tr style="border-bottom: 1px solid #eee;">
              <td style="padding: 10px 8px; color: #888; font-weight: bold;">Type</td>
              <td style="padding: 10px 8px;">${type || "Not specified"}</td>
            </tr>
            <tr>
              <td style="padding: 10px 8px; color: #888; font-weight: bold; vertical-align: top;">Message</td>
              <td style="padding: 10px 8px;">${comment.replace(/\n/g, "<br/>")}</td>
            </tr>
          </table>
        </div>
      `,
    });

    return NextResponse.json({ success: true });

  } catch (error: unknown) {
    // Log the real error to your terminal so you can diagnose it
    console.error("❌ Contact form error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
