// ThemeProvider.tsx — always starts in dark mode, never saves user preference
// storageKey is set to a dummy value and we override it on mount
// This ensures every visitor always sees dark mode regardless of previous visits

"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import { useEffect } from "react";

function ThemeReset() {
  useEffect(() => {
    // On every page load, clear any saved theme preference
    // This ensures dark mode is always shown to every visitor
    localStorage.removeItem("kenslab-theme");
    document.documentElement.classList.add("dark");
    document.documentElement.classList.remove("light");
  }, []);

  return null;
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="dark"
      storageKey="kenslab-theme"   // isolated key so it doesn't clash with other sites
      enableSystem={false}
    >
      <ThemeReset />
      {children}
    </NextThemesProvider>
  );
}
