import { notFound } from "next/navigation";
import BlogPost from "@/components/blog/BlogPost";
import { blogPosts } from "@/data/blog-posts";

type PageProps = {
  params: {
    slug: string;
  };
};

export function generateStaticParams() {
  return blogPosts.map((post) => ({
    slug: post.slug,
  }));
}

export function generateMetadata({ params }: PageProps) {
  const post = blogPosts.find((item) => item.slug === params.slug);

  if (!post) {
    return {
      title: "Post Not Found | KenLabs",
    };
  }

  return {
    title: `${post.title} | KenLabs`,
    description: post.excerpt,
  };
}

export default function BlogPostPage({ params }: PageProps) {
  const post = blogPosts.find((item) => item.slug === params.slug);

  if (!post) {
    notFound();
  }

  return <BlogPost post={post} />;
}
